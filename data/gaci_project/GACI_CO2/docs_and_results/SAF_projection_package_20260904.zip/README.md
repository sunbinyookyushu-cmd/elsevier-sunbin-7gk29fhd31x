# SAF and emissions-projection code, GACI x aviation CO2

Prepared for Ray and Lisa, 2026-09-04, in response to the two SAF comments.
Everything here is a draft. Please change anything you find useful to change,
including the elasticity choice, the growth path and the figure itself.

## 1. What the comments asked for

**(a) Traffic growth in the SAF scenarios.** The current draft holds 2023
scheduled traffic fixed, so the simulation is a pure blending identity,
`E(s, r) = E_2023 * (1 - s*r)`. `31_saf_growth.py` replaces it with

    E(t) = E_2023 * exp(beta * g * (t - 2023)) * (1 - s_t * r)

where `beta` is the mature-network elasticity of aviation CO2 with respect to
connectivity, `g` is annual growth in ln GACI, `s_t` is the ReFuelEU blend
share and `r` is the life-cycle saving of the blend.

- `beta = 3.005` (SE 1.187, p = 0.011, KP F = 10.7, N = 2,065): 2SLS on
  1996-2023 restricted to 2010-2023 excluding 2020-21, Extended Data Table 1
  Panel C, file `_temporal_excovid_cl.csv`, row
  `2010-2023_exCOVID / ln_co2_tot`. This is about half the full-sample 5.669,
  so it is the conservative choice. The full-sample value is carried in the
  script as a high case.
- `beta` is the reduced form on emissions, so the efficiency improvement
  estimated over the same window (intensity elasticity -0.979) is already
  netted out. Do not apply the seat-km elasticity (3.984) and then subtract
  efficiency separately; that double-counts it.
- `g`: mean annual change in country-level ln GACI (capacity-weighted mean)
  is 0.0074 over 2010-2019 (central) and 0.0045 over 2010-2023 with COVID
  included (low). With `beta = 3.005` these map to 2.25 and 1.36 percent
  annual emissions growth.

**(b) ReFuelEU framing.** Agreed, it is used as a benchmark blending path
applied uniformly so the arithmetic of a mandate is transparent, not as a
projection of global policy. The wording will be changed in the manuscript.

## 2. Result of the growth-inclusive version

World aviation CO2 in Mt per year, `beta = 3.005`, central growth
(2.25 percent per year), 2023 baseline 838 Mt:

| year | blend | no SAF | r = 50% | r = 65% | r = 80% |
|------|-------|--------|---------|---------|---------|
| 2023 | 0%    |  838   |  838    |  838    |  838    |
| 2030 | 6%    |  979   |  950    |  941    |  932    |
| 2035 | 20%   | 1094   |  985    |  952    |  919    |
| 2040 | 34%   | 1223   | 1015    |  953    |  890    |
| 2045 | 42%   | 1367   | 1080    |  994    |  908    |
| 2050 | 70%   | 1528   |  993    |  833    |  672    |

The fixed-traffic version in the current draft puts 2050 at 545 / 457 / 369 Mt
for the same three `r` values, so holding traffic fixed understates 2050
emissions by 450 to 500 Mt. Under the growth-inclusive version a 70 percent
blend at 65 percent life-cycle savings only returns 2050 emissions to roughly
the 2023 level, and none of the paths reach 482 Mt, which is 2023 minus the
356 Mt attributed to 1996-2023 connectivity growth. Blending buys back future
growth rather than the accumulated effect of past network expansion.

## 3. Files

Code, in the order it runs:

- `01_build_co2_panel.py`: Fangyu's airport-month emissions to a country-year
  CO2 panel, with the three allocation conventions (LTO only, bunker, 50/50).
  Needs the raw delivery, not included here; the output is.
- `03_merge_gaci.py`: merges that panel with the connectivity measures into
  the estimation panel.
- `04_carbon_price_saf.py`: carbon price of connectivity (g CO2 per USD of
  attributed trade) and the SAF scenarios on the price.
- `14_attribution_scc.py`: attribution of 2023 emissions to 1996-2023
  connectivity growth and the SCC valuation.
- `17_saf_levels_fig.py`: the current fixed-traffic SAF level figure.
- `31_saf_growth.py`: the growth-inclusive version described above. Self
  contained, needs only numpy, pandas and matplotlib.

Data:

- `gaci_co2_panel.csv`: the merged country-year estimation panel, 1996-2023,
  connectivity measures and emissions together. This is the most directly
  usable input if you want to re-estimate anything.
- `co2_country_year.csv`: the country-year emissions panel alone, all three
  allocation conventions, domestic and international.
- `_temporal_excovid_cl.csv`, `_temporal_pre2008_cl.csv`: the subperiod
  elasticities, including the mature-network estimate used above.
- `_allest_results_cl.csv`: main OLS and 2SLS estimates, all outcomes.
- `_attribution_scc.csv`: attributed emissions and SCC valuation by country.
- `_saf_growth_scenarios.csv`: every scenario cell in the new simulation,
  both beta cases and both growth cases.

Figures: `CO2_saf_growth.png` (new), `CO2_saf_levels.png` (current draft).

## 4. What is not here

The code that constructs the GACI connectivity index itself is not in this
project. It is produced in the connectivity paper's pipeline, and here we only
merge in the finished country-year measures (`gaci_panel_measures.csv`, whose
columns appear in `gaci_co2_panel.csv` as `ln_gaci_cwm`, `ln_gaci_mean`,
`ln_gaci_max`, `lnG` and the network centrality inputs). For construction and
properties, the connectivity manuscript is the reference. If you need the
construction code rather than the finished series, we will ask the coauthors
who built it.

## 5. Caveats worth keeping visible in the manuscript

- `beta` is estimated within countries with country and year fixed effects.
  Using it as a single world-level elasticity for a global projection is an
  approximation and should be flagged as such in the figure note.
- The mature-network first stage is weaker than the full-sample one
  (KP F = 10.7 against 18.4), which is another reason to present the growth
  path as a scenario rather than a forecast.
- The projection extrapolates a constant connectivity growth rate. An
  alternative is to feed in an external traffic forecast and use the same
  identity; the script is written so that only the `g` input changes.
